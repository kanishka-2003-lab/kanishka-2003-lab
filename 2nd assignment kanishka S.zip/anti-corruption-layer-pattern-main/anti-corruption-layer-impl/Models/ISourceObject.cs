namespace anti_corruption_layer.Models;

public interface ISourceObject
{
    string ServiceName { get; set; }
}